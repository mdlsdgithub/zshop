package com.study.zshop.common.constant;

public interface ProductTypeConstant {
    public static final int Product_TYPE_ENABLE=1;
    public static final int Product_TYPE_DISABLE=0;
}
