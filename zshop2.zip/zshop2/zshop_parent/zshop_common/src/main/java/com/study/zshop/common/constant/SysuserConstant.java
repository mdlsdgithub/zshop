package com.study.zshop.common.constant;

public interface SysuserConstant {
    public static final int SYSUSER_VALID=1;
    public static final int SYSUSER_INVALID=0;
}
