package com.study.zshop.common.util;

import com.study.zshop.common.constant.ResponseStatusConstant;

public class ResponseResult {
    //响应结果状态码
    private int status;
    private String message;
    private Object data;

    public int getStatus() {
        return status;
    }

    public ResponseResult() {
        super();
    }

    public ResponseResult(int status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }
public  static ResponseResult success(Object data){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_SUCCESS,"success",data);
}
    public  static ResponseResult success(){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_SUCCESS,"success",null);
    }
    public  static ResponseResult success(String message){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_SUCCESS,message,null);
    }
    public static  ResponseResult fail(){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_FAIL,"fail",null);
    }
    public static  ResponseResult fail(Object data){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_FAIL,"fail",data);
    }
    public static  ResponseResult fail(String message){
        return  new ResponseResult(ResponseStatusConstant.RESPONSE_STATUS_FAIL,message,null);
    }
    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
