package com.study.zshop.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class StringUtils {
    public static String renameFileName(String filename){
        int dotIndex=filename.lastIndexOf(".");
        String suffix=filename.substring(dotIndex);
        return  new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())+ new Random().nextInt(100)+suffix;
    }
}
