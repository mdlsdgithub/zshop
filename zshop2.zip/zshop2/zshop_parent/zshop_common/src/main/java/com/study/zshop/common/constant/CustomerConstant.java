package com.study.zshop.common.constant;

public interface CustomerConstant {
    public static  final int CUSTOMER_VALID=1;
    public static  final int CUSTOMER_INVALID=0;
}
