package com.study.zshop.common.constant;

public interface PageinationConstant {
    public static final int PAGE_NUM=1;
    public static final int PAGE_SIZE=5;
    public static final int PAGE_SIZE_FEONT=8;
}
