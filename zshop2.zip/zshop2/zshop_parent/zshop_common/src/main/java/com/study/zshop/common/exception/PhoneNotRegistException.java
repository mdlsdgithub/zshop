package com.study.zshop.common.exception;

public class PhoneNotRegistException extends Exception {
    public PhoneNotRegistException() {
        super();
    }

    public PhoneNotRegistException(String message) {
        super(message);
    }

    public PhoneNotRegistException(String message, Throwable cause) {
        super(message, cause);
    }

    public PhoneNotRegistException(Throwable cause) {
        super(cause);
    }

    protected PhoneNotRegistException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
