package com.study.zshop.service;

import com.study.zshop.common.exception.ProductTypeExistException;
import com.study.zshop.pojo.ProductType;

import java.util.List;

public interface ProductTypeService {
    public List<ProductType> findAll();
    public void add(String name) throws ProductTypeExistException;

    public ProductType findById(int id);

    public void modifyName(int id, String name) throws ProductTypeExistException;

     public void removeById(int id);

    public void modifyStatus(int id);

     public List<ProductType> findEnable();
}
