package com.study.zshop.service;

import com.study.zshop.pojo.Role;

import java.util.List;

public interface RoleService {
    public List<Role> findAll();
}
