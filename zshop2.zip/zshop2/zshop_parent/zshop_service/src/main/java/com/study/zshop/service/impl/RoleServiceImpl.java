package com.study.zshop.service.impl;

import com.study.zshop.dao.RoleDao;
import com.study.zshop.pojo.Role;
import com.study.zshop.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional(propagation = Propagation.REQUIRED)
public class RoleServiceImpl implements RoleService {
    @Autowired
private RoleDao roleDao;
    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public List<Role> findAll() {
        return roleDao.selectAll();
    }
}
