package com.study.zshop.service;

import com.study.zshop.common.exception.SysuserNotExistException;
import com.study.zshop.params.SysuserParams;
import com.study.zshop.pojo.Sysuser;
import com.study.zshop.vo.SysuserVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysuserService {
    public List<Sysuser> findAll();
    public Sysuser findById(int id);
    public void add(SysuserVo sysuserVo);
    public void modify(SysuserVo sysuserVo);
    public void modifyStatus( int id);

    List<Sysuser> findByParams(SysuserParams sysuserParams);

    Sysuser login(String loginName, String password) throws SysuserNotExistException;
}
