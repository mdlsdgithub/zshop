package com.study.zshop.service;

import com.study.zshop.dto.ProductDto;
import com.study.zshop.params.ProductParam;
import com.study.zshop.pojo.Product;
import org.apache.commons.fileupload.FileUploadException;

import java.io.OutputStream;
import java.util.List;

public interface ProductService {
    public void add(ProductDto productDto) throws FileUploadException;

    public boolean checkName(String name);

    List<Product> findAll();

    Product findById(int id);
    void modify(ProductDto productDto) throws FileUploadException;
     void removeById(int id);

    void getImage(String path, OutputStream outputStream);

    List<Product> findByParams(ProductParam productParam);
}
