package com.study.zshop.service;

import com.study.zshop.common.exception.LoginErrorException;
import com.study.zshop.common.exception.PhoneNotRegistException;
import com.study.zshop.pojo.Customer;

public interface CustomerService {
    public Customer login(String loginName,String password) throws LoginErrorException;

    Customer findByPhone(String phone) throws PhoneNotRegistException;
}
