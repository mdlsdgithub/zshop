package com.study.zshop.front.controller;

import com.study.zshop.common.constant.ResponseStatusConstant;
import com.study.zshop.common.util.HttpClientUtils;
import com.study.zshop.common.util.ResponseResult;

import com.study.zshop.pojo.Customer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Controller
@RequestMapping("/front/sms")
public class SmsController {
    @Value("${sms.url}")
    private String url;

    @Value("${sms.key}")
    private String key;

    @Value("${sms.tplId}")
    private String tplId;

    @Value("${sms.tplValue}")
    private String tplValue;
    @ResponseBody
    @RequestMapping("/sendVerificationCode")
    public ResponseResult sendVerificationCode(String phone, HttpSession session){
        try{
            Random random = new Random();
            int randVerificationCode = random.nextInt(999999);
            session.setAttribute("randVerificationCode",randVerificationCode);
            Map<String,String> params=new HashMap<>();
            params.put("mobile", phone);
            params.put("key", key);
            params.put("tpl_id", tplId);
            params.put("tpl_value", tplValue + randVerificationCode);
            String result=HttpClientUtils.doPost(url,params);
            System.out.println(result);
            return ResponseResult.success("验证码发送成功");
        }catch (Exception e){
           return ResponseResult.fail("验证码发送失败");
        }
    }

}
