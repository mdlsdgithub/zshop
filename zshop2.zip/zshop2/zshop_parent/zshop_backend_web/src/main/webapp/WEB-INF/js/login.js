function changeRigest(){
	$(".login-box").css({'display':'none'})
	$(".signup-box").css({'display':'block'})
}
function changeLogin(){
	$(".login-box").css({'display':'block'})
	$(".signup-box").css({'display':'none'})
}
