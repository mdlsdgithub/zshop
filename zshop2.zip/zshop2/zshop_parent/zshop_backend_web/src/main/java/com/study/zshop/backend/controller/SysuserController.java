package com.study.zshop.backend.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.study.zshop.common.constant.PageinationConstant;
import com.study.zshop.common.exception.SysuserNotExistException;
import com.study.zshop.common.util.ResponseResult;
import com.study.zshop.params.SysuserParams;
import com.study.zshop.pojo.Role;
import com.study.zshop.pojo.Sysuser;
import com.study.zshop.service.RoleService;
import com.study.zshop.service.SysuserService;
import com.study.zshop.vo.SysuserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/backend/sysuser")
public class SysuserController {
    @Autowired
    private SysuserService sysuserService;
    @Autowired
    private RoleService roleService;
    @RequestMapping("/login")
    public String Login(String loginName, String password, HttpSession session,Model model){
        try {
            Sysuser sysuser=sysuserService.login(loginName,password);
            session.setAttribute("sysuser",sysuser);
            return "main";
        } catch (SysuserNotExistException e) {
            model.addAttribute("errorMsg",e.getMessage());
            return "login";

        }

    }
    @RequestMapping("/findAll")
    public String findAll(Integer pageNum, Model model){
        if(ObjectUtils.isEmpty(pageNum)){
            pageNum= PageinationConstant.PAGE_NUM;
        }
        PageHelper.startPage(pageNum,PageinationConstant.PAGE_SIZE);
        List<Sysuser> sysusers=sysuserService.findAll();
        PageInfo<Sysuser> pageInfo = new PageInfo<>(sysusers);
        model.addAttribute("pageInfo",pageInfo);
        return "sysuserManager";
    }
    @RequestMapping("findByParams")
    public String findByParams(SysuserParams sysuserParams,Integer pageNum, Model model){
        if(ObjectUtils.isEmpty(pageNum)){
            pageNum= PageinationConstant.PAGE_NUM;
        }
        PageHelper.startPage(pageNum,PageinationConstant.PAGE_SIZE);
        List<Sysuser> sysusers=sysuserService.findByParams(sysuserParams);
        PageInfo<Sysuser> pageInfo = new PageInfo<>(sysusers);
        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("sysuserParam",sysuserParams);
        return "sysuserManager";
    }
    @ModelAttribute("roles")
    public List<Role> loadRoles(){

        return roleService.findAll();
    }
    @RequestMapping("/add")
    @ResponseBody
    public ResponseResult add(SysuserVo sysuserVo){
            sysuserService.add(sysuserVo);
            return ResponseResult.success();
    }
    @RequestMapping("/modifyStatus")
    @ResponseBody
    public ResponseResult modifyStatus(int id){
        sysuserService.modifyStatus(id);
        return ResponseResult.success();
    }
}
