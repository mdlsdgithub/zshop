package com.study.zshop.backend.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.study.zshop.common.constant.PageinationConstant;
import com.study.zshop.common.constant.ResponseStatusConstant;
import com.study.zshop.common.exception.ProductTypeExistException;
import com.study.zshop.common.util.ResponseResult;
import com.study.zshop.pojo.ProductType;
import com.study.zshop.service.ProductTypeService;
import javafx.scene.control.Pagination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@Controller
@RequestMapping("/backend/productType")
public class ProductTypeController {
    @Autowired
    private ProductTypeService productTypeService;
    @RequestMapping("/findAll")
    public String findAll(Integer pageNum,Model model){
        if(ObjectUtils.isEmpty(pageNum)){
            pageNum= PageinationConstant.PAGE_NUM;
        }
        //设置分页
        PageHelper.startPage(pageNum,PageinationConstant.PAGE_SIZE);
//查找所有对象
        List<ProductType> productTypes=productTypeService.findAll();
//将查找的结果分装到PageIndonesia对象中
        PageInfo<ProductType> pageInfo=new PageInfo<>(productTypes);

        model.addAttribute("pageInfo", pageInfo);
        return "productTypeManager";
    }



    @RequestMapping("/add")
    @ResponseBody
    public ResponseResult add(String name) {
        ResponseResult responseResult = new ResponseResult();
        try {
            productTypeService.add(name);
            responseResult.setStatus(ResponseStatusConstant.RESPONE_STATUS_SUCCESS);
            responseResult.setMessage("添加成功");

        } catch (ProductTypeExistException e) {
           responseResult.setStatus(ResponseStatusConstant.RESPONE_STATUS_FAIL);
           responseResult.setMessage(e.getMessage());
        }
        return responseResult;
    }

    @RequestMapping("/findById")
    @ResponseBody
    public ResponseResult findById(int id){
        ProductType productType=productTypeService.findById(id);
            return ResponseResult.success(productType);
    }
    @RequestMapping("/modifyName")
    @ResponseBody
    public ResponseResult modifyName(int id,String name){
        try {
            productTypeService.modifyName(id,name);
            return ResponseResult.success("修改商品类型成功");
        } catch (ProductTypeExistException e) {
            //e.printStackTrace();
            return ResponseResult.fail(e.getMessage());
        }
    }
    @ResponseBody
    @RequestMapping("/removeById")
    public ResponseResult deleteById(int id){
        productTypeService.removeById(id);
        return ResponseResult.success();
    }
    @ResponseBody
    @RequestMapping("/modifyStatus")
    public ResponseResult modifyStatus(int id){
        productTypeService.modifyStatus(id);
        return ResponseResult.success();
    }

}