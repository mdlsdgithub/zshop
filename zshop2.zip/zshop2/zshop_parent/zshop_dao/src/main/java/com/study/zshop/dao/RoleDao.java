package com.study.zshop.dao;

import com.study.zshop.pojo.Role;

import java.util.List;

public interface RoleDao {
    public List<Role> selectAll();
}
