package com.study.zshop.dao;

import com.study.zshop.params.ProductParam;
import com.study.zshop.pojo.Product;

import java.util.List;

public interface ProductDao {
    public void insert(Product product);
    Product selectByName(String name);

    List<Product> selectAll();
    Product selectById(int id);
    void update(Product product);
    void deleteById(int id);

    List<Product> selectByParams(ProductParam productParam);
}
