package com.study.zshop.dao;

import com.study.zshop.pojo.ProductType;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProductTypeDao {
    public List<ProductType> selectAll();
    public ProductType selectById(Integer id);
    public ProductType selectByName(String name);
    public void insert(@Param("name") String name,@Param("status") int status);
    public void updateName(@Param("id") int id,@Param("name") String name);
    public void updateStatus(@Param("id") int id,@Param("status") int status);
    public void delectById(int id);

    public List<ProductType> selectByStatus(int product_type_enable);
}
